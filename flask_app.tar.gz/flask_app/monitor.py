import sys
import time
import psutil

if len(sys.argv) < 2:
    print("Uso: python monitor.py <process_name_or_pid>")
    sys.exit(1)

process_identifier = sys.argv[1]

try:
    process = psutil.Process(int(process_identifier))
except ValueError:
    process = None
    for proc in psutil.process_iter(['pid', 'name']):
        if process_identifier == proc.info['name']:
            process = psutil.Process(proc.info['pid'])
            break

if not process:
    print(f"Processo {process_identifier} não encontrado.")
    sys.exit(1)

while True:
    cpu_usage = process.cpu_percent(interval=1)
    memory_info = process.memory_info().rss / (1024 * 1024)
    print(f"CPU: {cpu_usage}%, MEM: {memory_info:.2f}MB")
    time.sleep(4)
