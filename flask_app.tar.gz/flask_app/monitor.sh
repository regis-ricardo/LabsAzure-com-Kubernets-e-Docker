#!/bin/bash

if [ -z "$1" ]; then
  echo "Uso: $0 <process_name_or_pid>"
  exit 1
fi

while true; do
  if ps -p $1 > /dev/null; then
    CPU=$(ps -p $1 -o %cpu=)
    MEM=$(ps -p $1 -o %mem=)
    echo "CPU: $CPU%, MEM: $MEM%"
  else
    echo "Processo $1 não encontrado."
    exit 1
  fi
  sleep 5
done
